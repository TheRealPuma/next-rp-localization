export const luckyWheel = {
    header: {
        ru: "Колесо <span style='color: var(--golden-sunshine)'>удачи</span>",
        ua: "Колесо <span style='color: var(--golden-sunshine)'>удачі</span>",
        en: "Wheel <span style='color: var(--golden-sunshine)'>of Fortune</span>",
        de: "Rad <span style='color: var(--golden-sunshine)'>des Glücks</span>",
        pl: "Koło <span style='color: var(--golden-sunshine)'>Fortuny</span>",
    },
    desc: {
        ru: `Здесь вы можете прокрутить колесо с призами и получить ценные предметы, такие как фишки, деньги, донат валюту или даже машину, а также менее ценные призы, такие как опыт или одежда.
        <br><br>Каждый день вы будете получать бесплатную прокрутку после проведения 60 минут в игре.`,
        ua: `Тут ви можете прокрутити колесо з призами і отримати цінні речі, такі як фішки, гроші, донат валюту або навіть машину, а також менш цінні призи, такі як досвід або одяг.
        <br><br>Кожен день ви будете отримувати безкоштовний спін після проведення 60 хвилин в грі.`,
        en: `Here you can spin the wheel with prizes and get valuable items such as chips, money, donation currency, or even a car, as well as less valuable prizes like experience or clothing.
        <br><br>Every day, you'll receive a free spin after playing for 60 minutes in the game.`,
        de: `Hier kannst du das Rad mit Preisen drehen und wertvolle Gegenstände wie Chips, Geld, Spendenwährung oder sogar ein Auto erhalten, sowie weniger wertvolle Preise wie Erfahrung oder Kleidung.
        <br><br>Jeden Tag erhältst du einen kostenlosen Dreh, nachdem du 60 Minuten gespielt hast.`,
        pl: `Tutaj możesz obracać kołem z nagrodami i otrzymywać cenne przedmioty, takie jak żetony, pieniądze, walutę darowizn, a nawet samochód, a także mniej wartościowe nagrody, takie jak doświadczenie lub odzież.
        <br><br>Co dzień otrzymasz darmowy spin po 60 minutach grania w grę.`,
    },
    start: {
        ru: 'Пуск',
        ua: 'Пуск',
        en: 'Start',
        de: 'Start',
        pl: 'Rozpocznij',
        zh: '开始',
    },
    timeRemaining: {
        ru: 'Будет доступно через:',
        ua: 'Буде доступно через:',
        en: 'Available in:',
        de: 'Verfügbar in:',
        pl: 'Dostępne za:',
        zh: '可用选项',
    },
    onlineRemaining: {
        ru: 'Отыграйте ещё:',
        ua: 'Відіграйте ще:',
        en: 'Play for:',
        de: 'Spiele noch:',
        pl: 'Graj jeszcze:',
        zh: '为了:',
    },
    spinNow: {
        ru: 'Крутить сейчас',
        ua: 'Крутити зараз',
        en: 'Spin Now',
        de: 'Jetzt drehen',
        pl: 'Obróć teraz',
        zh: '自旋现在',
    },

    readyInCasino: {
        ru: 'Доступно для прокрутки в казино',
        ua: 'Доступно для прокрутки в казино',
        en: 'Available for spinning in the casino',
        de: 'Zum Drehen im Casino verfügbar',
        pl: 'Dostępne do kręcenia w kasynie',
    },

    chances: {
        ru: 'Шансы',
        ua: 'Шанси',
        en: 'Chances',
        de: 'Chancen',
        pl: 'Szanse',
        zh: '机遇',
    },

    winning: {
        ru: 'Вы выиграли - ',
        ua: 'Ви виграли - ',
        en: 'You won - ',
        de: 'Du hast gewonnen - ',
        pl: 'Wygrałeś - ',
        zh: '你赢了-',
    },

    anyPlayerSpins: {
        ru: 'Кто-то другой сейчас крутит колесо удачи. Подождите, пожалуйста.',
        ua: 'Хтось інший зараз крутить колесо удачі. Зачекайте, будь ласка.',
        en: 'Someone else is spinning the Wheel of Fortune right now. Please wait.',
        de: 'Jemand anderes dreht gerade das Glücksrad. Bitte warte.',
        pl: 'Ktoś inny teraz kręci Kołem Fortuny. Proszę czekać.',
        zh: '另一位玩家正在转轮盘,请稍等',
    },

    prizes: {
        clothing: {
            ru: 'одежду',
            ua: 'одяг',
            en: 'clothing',
            de: 'Kleidung',
            pl: 'ubrania',
            zh: '衣服',
        },
        exp: {
            ru: 'опыт',
            ua: 'досвід',
            en: 'experience',
            de: 'Erfahrung',
            pl: 'doświadczenie',
            zh: '经验',
        },
        money: {
            ru: 'деньги',
            ua: 'гроші',
            en: 'money',
            de: 'Geld',
            pl: 'pieniądze',
            zh: '钱',
        },
        chips: {
            ru: 'фишки',
            ua: 'фішки',
            en: 'chips',
            de: 'Chips',
            pl: 'żetony',
            zh: '筹码',
        },
        mystery: {
            ru: 'случайный предмет',
            ua: 'випадковий предмет',
            en: 'mystery item',
            de: 'Überraschungsgegenstand',
            pl: 'przedmiot tajemnicy',
            zh: '神秘奖品',
        },
        donate: {
            ru: 'донат-валюту',
            ua: 'донат-валюту',
            en: 'donation currency',
            de: 'Spendenwährung',
            pl: 'waluta darowizn',
            zh: '捐赠货币',
        },
        vehicle: {
            ru: 'автомобиль',
            ua: 'автомобіль',
            en: 'vehicle',
            de: 'Fahrzeug',
            pl: 'pojazd',
            zh: '载具奖品',
        },
    },

    name: {
        ru: 'Колесо удачи',
        ua: 'Колесо удачi',
        en: 'Wheel of Fortune',
        de: 'Glücksrad',
        pl: 'Koło Fortuny',
        zh: '幸运轮盘',
    },

    roulette: {
        ru: 'Рулетка',
        ua: 'Рулетка',
        en: 'Roulette',
        de: 'Roulette',
        pl: 'Ruletka',
        zh: '轮盘赌',
    },
    win: {
        ru: 'Вы выиграли {{rewardSum}} фишек',
        ua: 'Ви виграли {{rewardSum}} фішок',
        en: 'You won {{rewardSum}} chips',
        de: 'Du hast {{rewardSum}} Chips gewonnen',
        pl: 'Wygrałeś {{rewardSum}} żetonów',
        zh: '你赢得了{{rewardSum}}筹码',
    },
    maxChips: {
        ru: 'Вы уже поставили максимум ставок на эту ячейку',
        ua: 'Ви вже поставили максимум ставок на цю клітинку',
        en: 'You have already placed the maximum bet on this cell',
        de: 'Du hast bereits den maximalen Einsatz auf diese Zelle gesetzt',
        pl: 'Ustawiłeś już maksymalny zakład na tę komórkę',
        zh: '你已经在这个单元格下了最大的赌注',
    },
    discord: {
        ru: 'Играет в рулетку',
        ua: 'Грає в рулетку',
        en: 'Playing roulette',
        de: 'Spielt Roulette',
        pl: 'Gra w ruletkę',
        zh: '玩轮盘赌',
    },
};
