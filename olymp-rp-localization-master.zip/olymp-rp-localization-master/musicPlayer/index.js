export default {
    title: {
        ru: 'Плеер',
        ua: 'Плеєр',
        en: 'Player',
        de: 'Player',
        pl: 'Odtwarzacz',
    },

    notEnoughLevel: {
        ru: 'Для использования плеера требуется как минимум {{requiredLevel}} уровень',
        ua: 'Для використання плеєра потрібен щонайменше {{requiredLevel}} рівень',
        en: 'To use the player, at least level {{requiredLevel}} is required',
        de: 'Um den Player zu verwenden, wird mindestens Level {{requiredLevel}} benötigt',
        pl: 'Do korzystania z odtwarzacza wymagany jest co najmniej poziom {{requiredLevel}}',
    },

    copied: {
        ru: 'Ссылка на трек и его название скопированы в буфер обмена',
        ua: 'Посилання на трек і його назва скопійовані в буфер обміну',
        en: 'The track link and its name have been copied to the clipboard',
        de: 'Der Link zum Track und dessen Name wurden in die Zwischenablage kopiert',
        pl: 'Link do utworu i jego nazwa zostały skopiowane do schowka',
    },

    notAvailableForNow: {
        ru: 'Эта функция пока что недоступна',
        ua: 'Ця функція поки що недоступна',
        en: 'This feature is not available for now',
        de: 'Diese Funktion ist derzeit nicht verfügbar',
        pl: 'Ta funkcja jest obecnie niedostępna',
    },

    uCantPlaceBoomboxHere: {
        ru: 'Здесь нельзя разместить бумбокс',
        ua: 'Тут не можна розмістити бумбокс',
        en: "You can't place a boombox here",
        de: 'Du kannst hier keine Boombox platzieren',
        pl: 'Nie możesz umieścić boomboxa tutaj',
    },

    musicPlayerRemoved: {
        ru: 'Ваш плеер {{id}} был удален',
        ua: 'Ваш плеєр {{id}} був видалений',
        en: 'Your player {{id}} has been removed',
        de: 'Dein Player {{id}} wurde entfernt',
        pl: 'Twój odtwarzacz {{id}} został usunięty',
    },

    waitForSearch: {
        name: {
            ru: 'Введите запрос',
            ua: 'Введіть запит',
            en: 'Enter a query',
            de: 'Gib eine Such-Anfrage ein',
            pl: 'Wpisz zapytanie',
        },
        desc: {
            ru: 'Введите название желаемой композиции в поле поиска выше и нажмите на Enter',
            ua: 'Введіть назву бажаної композиції у поле пошуку вище та натисніть Enter',
            en: 'Enter the name of the desired track in the search field above and press Enter',
            de: 'Gib den Namen des gewünschten Titels in das obige Suchfeld ein und drücke Enter',
            pl: 'Wpisz nazwę żądanej kompozycji w polu wyszukiwania powyżej i naciśnij Enter',
        },
    },

    emptyResults: {
        name: {
            ru: 'Ничего не найдено',
            ua: 'Нічого не знайдено',
            en: 'Nothing found',
            de: 'Nichts gefunden',
            pl: 'Nic nie znaleziono',
        },
        desc: {
            ru: 'По вашему запросу ничего не найдено, попробуйте изменить его и попробовать снова',
            ua: 'За вашим запитом нічого не знайдено, спробуйте змінити його та спробувати знову',
            en: 'No results found for your query, try changing it and searching again',
            de: 'Für deine Anfrage wurden keine Ergebnisse gefunden, versuche sie zu ändern und erneut zu suchen',
            pl: 'Nie znaleziono wyników dla Twojego zapytania, spróbuj je zmienić i wyszukać ponownie',
        },
    },

    emptyFavorites: {
        name: {
            ru: 'Избранное',
            ua: 'Обране',
            en: 'Favorites',
            de: 'Favoriten',
            pl: 'Ulubione',
        },
        desc: {
            ru: 'Здесь появятся треки, которые вы оценили, нажав на сердечко, для быстрого доступа',
            ua: 'Тут з’являться треки, які ви оцінили, натиснувши на сердечко, для швидкого доступу',
            en: 'Here you will find tracks you liked by clicking the heart for quick access',
            de: 'Hier erscheinen Tracks, die du mit einem Herz markiert hast, für schnellen Zugriff',
            pl: 'Tutaj pojawią się utwory, które polubiłeś, klikając serduszko, dla szybkiego dostępu',
        },
    },

    emptyRecent: {
        name: {
            ru: 'Последние треки',
            ua: 'Останні треки',
            en: 'Recent tracks',
            de: 'Zuletzt gehört',
            pl: 'Ostatnie utwory',
        },
        desc: {
            ru: 'Здесь будут отображаться последние треки, которые вы слушали',
            ua: 'Тут відображатимуться останні треки, які ви слухали',
            en: 'Here you will find the most recently played tracks',
            de: 'Hier erscheinen die zuletzt abgespielten Titel',
            pl: 'Tutaj pojawią się ostatnio odtwarzane utwory',
        },
    },

    startPage: {
        header: {
            ru: 'Добро пожаловать в панеле управления музыкального плеера!',
            ua: 'Ласкаво просимо до панелі управління музичного плеєра!',
            en: 'Welcome to the music player control panel!',
            de: 'Willkommen im Steuerungspanel des Musikplayers!',
            pl: 'Witamy w panelu sterowania odtwarzacza muzyki!',
        },

        desc: {
            ru: 'Здесь вы можете включить любую доступную музыку которую услышат все игроки поблизости. <br><br> Но пожалуйста, соблюдайте некоторые правила: Не включайте аморальный, оскорбительный, провокационный, трешовый контент. <br><br> В зелёных зонах, музыка из плеера будет глушится. <br><br> Используй эту систему разумно, чтобы приносить пользу и удовольствие себе и другим игрокам, в противном случае вы будите наказаны.',
            ua: 'Тут ви можете увімкнути будь-яку доступну музику, яку почують усі гравці поблизу. <br><br> Але, будь ласка, дотримуйтесь деяких правил: не вмикайте аморальний, образливий, провокаційний або трешовий контент. <br><br> У зелених зонах музика з плеєра буде глушитися. <br><br> Використовуйте цю систему розумно, щоб приносити користь і задоволення собі та іншим гравцям, інакше ви будете покарані.',
            en: 'Here you can play any available music that all nearby players will hear. <br><br> But please follow some rules: Do not play immoral, offensive, provocative, or trash content. <br><br> In green zones, the music from the player will be muted. <br><br> Use this system wisely to bring enjoyment and benefit to yourself and other players; otherwise, you will be punished.',
            de: 'Hier kannst du jede verfügbare Musik abspielen, die alle nahegelegenen Spieler hören können. <br><br> Aber bitte halte dich an einige Regeln: Spiele keine unmoralischen, beleidigenden, provokativen oder trashigen Inhalte ab. <br><br> In grünen Zonen wird die Musik des Players stummgeschaltet. <br><br> Nutze dieses System mit Bedacht, um dir selbst und anderen Spielern Freude zu bereiten, andernfalls wirst du bestraft.',
            pl: 'Tutaj możesz odtwarzać dowolną dostępną muzykę, którą usłyszą wszyscy pobliscy gracze. <br><br> Ale proszę, przestrzegaj kilku zasad: nie odtwarzaj treści niemoralnych, obraźliwych, prowokacyjnych ani śmieciowych. <br><br> W zielonych strefach muzyka z odtwarzacza zostanie wyciszona. <br><br> Korzystaj z tego systemu mądrze, aby sprawiać radość sobie i innym graczom, w przeciwnym razie zostaniesz ukarany.',
        },
    },

    uHaveNoAccess: {
        ru: 'У вас нет доступа к этому плееру',
        ua: 'У вас немає доступу до цього плеєра',
        en: 'You have no access to this player',
        de: 'Du hast keinen Zugriff auf diesen Player',
        pl: 'Nie masz dostępu do tego odtwarzacza',
    },

    tooManyFavorites: {
        ru: 'Вы можете добавить в избранное не более {{maxFavorites}} треков',
        ua: 'Ви можете додати в обране не більше {{maxFavorites}} треків',
        en: 'You can add no more than {{maxFavorites}} tracks to favorites',
        de: 'Du kannst nicht mehr als {{maxFavorites}} Titel zu den Favoriten hinzufügen',
        pl: 'Możesz dodać do ulubionych nie więcej niż {{maxFavorites}} utworów',
    },

    remove: {
        ru: 'Убрать',
        ua: 'Прибрати',
        en: 'Remove',
        de: 'Entfernen',
        pl: 'Usuń',
    },

    public: {
        allowButton: {
            ru: 'Разрешить',
            ua: 'Дозволити',
            en: 'Allow',
            de: 'Erlauben',
            pl: 'Zezwolić',
        },
        denyButton: {
            ru: 'Запретить',
            ua: 'Заборонити',
            en: 'Deny',
            de: 'Verweigern',
            pl: 'Odmówić',
        },

        allow: {
            ru: 'Доступ другим игрокам к плееру разрешён',
            ua: 'Доступ іншим гравцям до плеєра дозволено',
            en: 'Access to the player for other players is allowed',
            de: 'Der Zugriff auf den Player für andere Spieler ist erlaubt',
            pl: 'Dostęp do odtwarzacza dla innych graczy jest dozwolony',
        },
        deny: {
            ru: 'Доступ другим игрокам к плееру запрещён',
            ua: 'Доступ іншим гравцям до плеєра заборонено',
            en: 'Access to the player for other players is denied',
            de: 'Der Zugriff auf den Player für andere Spieler ist verboten',
            pl: 'Dostęp do odtwarzacza dla innych graczy jest zabroniony',
        },
    },

    uDisconnected: {
        ru: 'Вы были отключены, доступ к плееру ограничен.',
        ua: 'Вас було відключено, доступ до плеєра обмежено.',
        en: 'You have been disconnected, access to the player is restricted.',
        de: 'Du wurdest getrennt, der Zugriff auf den Player ist eingeschränkt.',
        pl: 'Zostałeś rozłączony, dostęp do odtwarzacza jest ograniczony.',
    },

    musicPlayerTooClose: {
        ru: 'Плеер с id: {{id}} находится слишком близко',
        ua: 'Плеєр з id: {{id}} знаходиться занадто близько',
        en: 'The player with id: {{id}} is too close',
        de: 'Der Player mit der ID: {{id}} ist zu nah',
        pl: 'Odtwarzacz z id: {{id}} jest za blisko',
    },

    mutedInGreenZone: {
        ru: 'Заглушено в зелёной зоне',
        ua: 'Приглушено в зеленій зоні',
        en: 'Muted in green zone',
        de: 'In der grünen Zone stummgeschaltet',
        pl: 'Wyciszone w zielonej strefie',
    },
};
