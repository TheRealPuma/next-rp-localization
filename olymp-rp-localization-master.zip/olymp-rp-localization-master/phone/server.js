export const server = {
 
};
